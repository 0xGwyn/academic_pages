import cv2
import datetime
import numpy as np
from gpiozero import Buzzer
from time import sleep

out = None
def capture():
    global out
    time = datetime.datetime.now()
    out = cv2.VideoWriter(f'output_{time.strftime("%Y-%b-%d_%H:%M:%S")}.avi',fourcc, 20.0, (640, 480))

buzzer = Buzzer(17)
cap = cv2.VideoCapture(0)
last_mean = 0
frame_rec_count = 0
fourcc = cv2.VideoWriter_fourcc(*'XVID')
capturing = False
while(True):
    ret, frame = cap.read()
    #cv2.imshow('frame',frame)
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    result = np.abs(np.mean(gray) - last_mean)
    print(result)
    last_mean= np.mean(gray)
    #sensitivity
    if result > 2 :
        print("Motion detected!")
        #do not capture another footage while capturing one
        if not capturing:
            print("Started recording.")
            capture()
            capturing = True
    #appending frames to make an avi file
    if capturing:
        out.write(frame)
        #buzzer works while capturing
        if frame_rec_count in [0,20,40,60,80,99]:
            buzzer.on()
        elif frame_rec_count in [10,30,50,70,90]:
            buzzer.off()
        frame_rec_count = frame_rec_count + 1
    #checks if 5 seconds has elapsed
    if frame_rec_count == 100:
        frame_rec_count = 0
        capturing = False