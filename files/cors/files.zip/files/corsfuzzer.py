import requests, argparse, sys, datetime, tldextract, time, random, json

# Ignoring SSL warnings
requests.packages.urllib3.disable_warnings(category=requests.packages.urllib3.exceptions.InsecureRequestWarning)


def parse_args():
    parser = argparse.ArgumentParser(prog='CORS fuzzer',description="CORS Misconfiguration Checker")
    parser.add_argument("-l", "--list", default=False, required=False, help='List of targets. One per line.')
    parser.add_argument("-s", "--stdin", default=False, action="store_true", help='Use stdin to pass targets. (default: False)')
    parser.add_argument("-v", "--verbose", default=False, action="store_true", help='verbose output messages. (default: False)')
    parser.add_argument("-tl", "--subdomainlist", default=False, help='List of subdomains in order to test on target for CORS Header check.')
    parser.add_argument("-ts", "--subdomain", default=False, help='Single subdomain in order to test on target for CORS Header check.')
    parser.add_argument("-x", "--header", default=[], nargs='+', help='Any custom headers that you want to add to each request. ("key1:value1" "key2:value2")')
    parser.add_argument("-c", "--cookie", default=False, help='Cookie values for each request.')
    parser.add_argument("-ua", "--useragent", default=False, help='Custom user-agent for requests.')
    parser.add_argument("-d", "--delay", default=False, help='Delay between each request to targets (5 | 1-3)')
    parser.add_argument("-z", "--testmisconfig", default=True, action="store_true", help='Test for CORS misconfigs. (Default: True)')
    parser.add_argument("-w", "--attackerdomain", default="attacker.com", help='Sample domain to test as Attacker-Domain (Default: attacker.com)')
    parser.add_argument("-o", "--output", default=False, help='Output filename to save output into.')
    parser.add_argument("-e", "--timeout", default=10, help='Request timeout in seconds (Default: 10).')
    return parser.parse_args()

options = parse_args()

targets = []
subdomains = []

#checks whether input is provided from a list or stdin
if options.stdin and not options.list:
    for target in sys.stdin:
        targets.append(target.strip())
elif options.list and not options.stdin:
    file_handle = open(options.list, "r", encoding="utf-8", errors="ignore")
    file_read = file_handle.readlines()
    for target in file_read:
        targets.append(target.strip())
    file_handle.close()
else:
    print("[-] Choose one option (-s or -l).")
    sys.exit(0)

#attacker domain should not have a scheme
if "http" in options.attackerdomain or "https" in options.attackerdomain:
    print("[-] Enter attacker-domain without scheme.")
    sys.exit(0)

if options.useragent:
    useragent = options.useragent
else:
    useragent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:99.0) Gecko/20230831 Firefox/99.0"

request_headers = {
    "User-Agent": useragent
}

if options.cookie:
    request_headers["Cookie"] = options.cookie

if len(options.header) != 0:
    try:
        for header in options.header:
            key, value = header.split(':', 1)
            request_headers[key] = value
    except:
        print('[-] Enter custom header in valid format!\nFormat --> -x "key1:value1" "key2:value2"')
        sys.exit(0)

if options.delay:
    if "-" in options.delay:
        start_range, end_range = options.delay.split("-")
        delay_range = list(range(int(start_range), int(end_range)+1))
    else:
        delay_range = [int(options.delay)]
else:
    delay_range = [0]

if options.output:
    output_handle = open(options.output, "w", encoding="utf-8", errors="ignore")
    output = []

#extract subdomain, domain and tld from a url
def clean_target(data):
    parsed_url = tldextract.extract(data)
    extracted_subdomain = parsed_url.subdomain
    extracted_domain = parsed_url.domain
    extracted_tld = parsed_url.suffix
    final_subdomain = f"{extracted_subdomain}.{extracted_domain}.{extracted_tld}"
    #url might not have a subdomain therefore there might be one extra [dot] character inside the string
    final_subdomain = final_subdomain[1:] if final_subdomain[0] == "." else final_subdomain
    return final_subdomain


if options.subdomainlist:
    file_handle = open(options.subdomainlist, "r", encoding="utf-8", errors="ignore")
    file_read = file_handle.readlines()
    for subdomain in file_read:
        subdomain = subdomain.strip()
        final_subdomain = clean_target(subdomain)
        subdomains.append(final_subdomain)
    file_handle.close()

if options.subdomain:
    final_subdomain = clean_target(options.subdomain)
    subdomains.append(final_subdomain)

def print_verbose(message):
    if options.verbose:
        print(message)

def current_time():
    return str(datetime.datetime.now())[:19]


def run_attack(target="", scheme="", domain="", attacker_domain="", subdomains=False):
    origins = [
        f"{scheme}://NonExistenceSubdomainToTest.{domain}"
        f"{scheme}://{domain}.{attacker_domain}",
        f"{scheme}://{domain}_{attacker_domain}",
        f"{scheme}://{attacker_domain}",
        f"{scheme}://{domain}{attacker_domain}",
        f"{scheme}://{attacker_domain}{domain}",
        "null",
        "sample.computer",
        f"{scheme}://{domain}%09{attacker_domain}",
        f"{scheme}://{domain}%60.{attacker_domain}",
        f"{scheme}://foo@{attacker_domain}:80@{domain}",
        f"{scheme}://foo@{attacker_domain}%20{domain}"
        f"{scheme}://{domain}@{attacker_domain}",
        f"{scheme}://{domain}#{attacker_domain}",
        f"{scheme}://{domain}\@{attacker_domain}",
        f"{scheme}://{domain}:\@@{attacker_domain}",
        f"{scheme}://{domain}#\@{attacker_domain}",
        f"{scheme}://ß.{attacker_domain}",
    ]

    #checking for potential allowed subdomains (there might be a use to leverage xss on these subdomains for csrf attacks)
    if subdomains:
        print_verbose(f"[*] Testing For Subdomains Allowed Origins. [{current_time()}]")
        #testword type(subdommain_list) is list
        if "list" not in str(type(subdomains)):
            return 0

        for subdomain in subdomains:
            subdomain = f"{scheme}://{subdomain}" if "http" not in subdomain else subdomain
            request_headers["origin"] = subdomain
            try:
                attack_request = requests.get(target, headers=request_headers, verify=False, timeout=int(options.timeout))
            except Exception as e:
                print_verbose(f"[-] Request failed: \n\t{e}")
                continue
            response_headers = attack_request.headers
            delay = random.choice(delay_range)
            if "Access-Control-Allow-Credentials" in response_headers.keys() and "Access-Control-Allow-Origin" in response_headers.keys():
                tmp_output = {}
                tmp_output["origin"] = subdomain
                tmp_output["target"] = target
                tmp_output["Access-Control-Allow-Credentials"] = response_headers["Access-Control-Allow-Credentials"]
                tmp_output["type"] = "potential subdomain"
                print_output = str(tmp_output).replace('"', r'\"').replace("'", '"')
                print("**********************************")
                print(print_output)
                if options.output:
                    output.append(tmp_output)
            time.sleep(int(delay))

    #checking for misconfig
    if not subdomains and options.testmisconfig:
        print_verbose(f"[*] Testing Origin Misconfiguration. [{current_time()}]")
        for origin in origins:
            request_headers["origin"] = origin
            try:
                attack_request = requests.get(target, headers=request_headers, verify=False, timeout=int(options.timeout))
            except Exception as e:
                print_verbose(f"[-] Request failed: \n\t{e}")
                continue
            response_headers = attack_request.headers
            delay = random.choice(delay_range)
            if "Access-Control-Allow-Credentials" in response_headers.keys() and "Access-Control-Allow-Origin" in response_headers.keys():
                tmp_output = {}
                tmp_output["origin"] = origin
                tmp_output["target"] = target
                tmp_output["Access-Control-Allow-Credentials"] = response_headers["Access-Control-Allow-Credentials"]
                tmp_output["type"] = "potential misconfig"
                #testword
                print_output = str(tmp_output).replace('"', r'\"').replace("'", '"')
                print("**********************************")
                print(print_output)
                if options.output:
                    output.append(tmp_output)
            time.sleep(int(delay))

for target in targets:
    if "http://" in target:
        scheme = "http"
    elif "https://" in target:
        scheme = "https"
    else:
        print_verbose(f"[WRN] No schema was provided for [{target}], using HTTPS.")
        scheme = "https"
        target = f"{scheme}://{target}"

    raw_target = clean_target(target)

    print_verbose(f"[+] Running payloads: {current_time()}")
    run_attack(target, scheme, raw_target, options.attackerdomain, False)
    if len(subdomains) < 1:
        print_verbose("[-] No subdomains were provided, skipping subdomain whitelist checks...")
    else:
        run_attack(target=target, scheme=scheme, subdomains=subdomains)

    if options.output:
        if len(output) != 0:
            json.dump(output, output_handle)
        output.clear()