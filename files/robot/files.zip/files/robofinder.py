import requests, argparse, sys, time, re

# Ignoring SSL warnings
requests.packages.urllib3.disable_warnings(category=requests.packages.urllib3.exceptions.InsecureRequestWarning)


def print_message(message):
    if not options.silent:
        print(message)

def print_verbose(message):
    if options.verbose and not options.silent:
        print(message)

def check_options(options):
    if not options.url:
        print("[-] Enter URL in following format: scheme://domain.tld")
        sys.exit(0)

    if "http" not in str(options.url).lower():
        print("[-] Enter URL with it's scheme. (http|https)")
        sys.exit(0)

    if options.url.count("/") > 3:
        print("[-] Only enter domain name, not full URL\nFormat: scheme://domain.tld")
        sys.exit(0)

    if options.silent and options.verbose:
        print("[-] Can not use -q with -v at the same time.")
        sys.exit(0)

    if not options.paths and not options.sitemap:
        print("[-] Either use -a or -s in order to extract data.")
        sys.exit(0)

def parse_args():
    parser = argparse.ArgumentParser(description="Gathering robots.txt Contents From Archive.")
    parser.add_argument("-u", "--url", help="Target url", default=False)
    parser.add_argument("-d", "--delay", help="Amount of delay between each request\n\tDefault: 0.5(s)", action="store", default=0.5, type=float)
    parser.add_argument("-l", "--limit", help="Limit for timestamps (negative numbers can be used for the last recent results)\n\tDefault: 10", action="store", default=10, type=int)
    parser.add_argument("-p", "--paths", help="Show robots.txt paths", action="store_true")
    parser.add_argument("-sm", "--sitemap", help="Show robots.txt sitemaps", action="store_true")
    parser.add_argument("-s", "--silent", help="Silent output messages.", action="store_true")
    parser.add_argument("-v", "--verbose", help="Show debug level messages.", action="store_true")
    return parser.parse_args()

options = parse_args()
check_options(options)

base_domain = options.url
if base_domain[-1] == "/":
    base_domain = base_domain[:-1]
domain = f"{base_domain}/robots.txt"
limit = options.limit

# Documents can be found here https://github.com/internetarchive/wayback/tree/master/wayback-cdx-server
timestamps_url = f"https://web.archive.org/cdx/search/cdx?url={domain}&output=json&filter=statuscode:200&fl=timestamp,original&collapse=digest&limit={limit}"
response = requests.get(timestamps_url, verify=False, timeout=15).json()
timestamps = []

#Index 0 contains name of the fields (columns)
for item in response[1:]:
   #if item[0] != "timestamp":
    try:
        timestamp = item[0]
        address = item[1]
    except Exception as e:
        print_verbose(f"[DEBUG] Request error: {e}")
        continue
    #the if_ part removes the timeline bar at the top of the page
    request_address = f"http://web.archive.org/web/{timestamp}if_/{address}"
    # request_address = f"http://web.archive.org/web/{timestamp}/{address}"
    timestamps.append(request_address)

print_message(f"[+] Found [{len(timestamps)}] Timestamps.")

address_regex = "(?i)allow(\s?):(\s?)(.*)"
sitemap_regex = "(?i)(sitemap|site-map)(\s?):(\s?)(.*)"
target_sitemaps = set()
target_urls = set()

print_message("[+] Fetching timestamps")
for timestamp in timestamps:
    print_verbose(f"[DEBUG] Getting New Timestamp Data.\n\t{timestamp}")
    time.sleep(int(options.delay))
    try:
        response = requests.get(timestamp, verify=False, timeout=15).content.decode("utf-8")
    except Exception as e:
        print_verbose(f"[DEBUG] Error On Request: {e}")
        continue
    for line in response.split("\n"):
        address_matched_items = re.findall(address_regex, line)
        sitemap_matched_items = re.findall(sitemap_regex, line)

        if len(address_matched_items) > 0:
            try:
                matched_address = address_matched_items[0][-1]
                if "/" not in matched_address[0]:
                    matched_address = f"/{matched_address}"
            except:
                continue

            final_url = f"{base_domain}{matched_address}"
            if options.paths and final_url not in target_urls:
                print(final_url)
            target_urls.add(final_url)

        if len(sitemap_matched_items) > 0:
            try:
                final_sitemap = sitemap_matched_items[0][-1]
                if options.sitemap and final_sitemap not in target_sitemaps:
                    print(final_sitemap)
                target_sitemaps.add(final_sitemap)
            except:
                continue

if options.paths and not options.silent:
    if len(target_urls) < 1:
        print_message("[-] No URL was found from robots.txt")

if options.sitemap and not options.silent:
    if len(target_sitemaps) < 1:
        print_message("[-] No sitemap was found from robots.txt")
