import ply.lex as lex
import ply.yacc as yacc

reserved = {
    'class': "CLASS",
    'str': "STR",
    'int': "INT",
    'while': "WHILE",
    'if': "IF",
    'else': "ELSE",
    'main': "MAIN",
    'integer' : "INTEGER_TYPE",
    'string' : "STRING_TYPE",
    'bool' : "BOOL_TYPE",
    'and' : "AND",
    'or' : "OR",
    'not' : "NOT",
}

tokens = [
    'ID',
    'INPUT', 'OUTPUT',
    'INTEGER', 'STRING', 
    'BOOL', 
    'EQ', 'PLUS',
    'MINUS', 'ASSIGN', 
    'LPAREN', 'RPAREN',
    'GTS', 'LTS', 'LCBRACK',
    'RCBRACK', 'SEMICOLON'
] + list(reserved.values())

 # Special symbols
t_EQ = r'=='
t_PLUS = r'\+'
t_MINUS = r'-'
t_ASSIGN = r'='
t_LPAREN = r'\('
t_RPAREN = r'\)'
t_GTS = r'>' #greater than sign
t_LTS = r'<' #less than sign
t_LCBRACK = r'\{' #left curly bracket
t_RCBRACK = r'\}' #right curly bracket
t_SEMICOLON = r';'


def t_AND(t):
    r'and'
    t.type = "AND"
    return t

def t_OR(t):
    r'or'
    t.type = "OR"
    return t

def t_NOT(t):
    r'not'
    t.type = "NOT"
    return t

def t_IF(t):
    r'if'
    t.type = "IF"
    return t

def t_CLASS(t):
    r'class'
    t.type = "CLASS"
    return t

def t_STR(t): #?
    r'STR'
    t.type = "STR"
    return t

def t_INT(t): #?
    r'INT'
    t.type = "INT"
    return t

def t_ELSE(t):
    r'else'
    t.type = "ELSE"
    return t

def t_WHILE(t):
    r'while'
    t.type = "WHILE"
    return t

def t_MAIN(t):
    r'main'
    t.type = "MAIN"
    return t

def t_INPUT(t):
    r'input'
    t.type = "INPUT"
    return t

def t_OUTPUT(t):
    r'output'
    t.type = "OUTPUT"
    return t

def t_BOOL(t):
    r'(True)|(False)'
    t.type = "BOOL"
    t.value = t.value == "True"
    return t

def t_BOOL_TYPE(t):
    r'bool'
    t.type = "BOOL_TYPE"
    return t

def t_STRING(t):
    r'".*?"'
    t.value = str("".join(t.value[:]))
    return t

def t_INTEGER(t):
    r'\d+'
    t.value = int(t.value)
    return t

def t_STRING_TYPE(t):
    r'string'
    t.type = "STRING_TYPE"
    return t

def t_INTEGER_TYPE(t):
    r'integer'
    t.type = "INTEGER_TYPE"
    return t

def t_ID(t):
    r'[a-zA-Z_][a-zA-Z0-9_]*'
    if not(t.value in reserved.values()):
        t.type = "ID"
        return t

def t_newline(t):
    r'\n+'
    t.lexer.lineno += len(t.value)

t_ignore = ' \t'

def t_error(t):
    print("Illegal character '%s'" % t.value[0])
    t.lexer.skip(1)



lexer = lex.lex()

variables = {}

# def p_class(p):
#     '''
#         class : CLASS MAIN LCBRACK statements RCBRACK
#     '''
#     p[0] = p[4]

def p_statements(p):
    '''
        statements : statement
        | statements statement
    '''
    try:
        if p[1] is not None and p[2] is not None:
            p[0] = [p[1], p[2]]
        elif p[1] is not None:
            p[0] = p[1]
        elif p[2] is not None:
            p[0] = p[2]
    except IndexError:
        if p[1] is not None:
            p[0] = p[1]

def p_statement(p):
    '''
        statement : assign_s SEMICOLON
        | output SEMICOLON
        | if_s
        | input SEMICOLON 
        | type_cast SEMICOLON
    '''
    if p[1] is not None:
        p[0] = p[1]

def p_if_s(p):
    '''
        if_s : IF LPAREN logic_o RPAREN LCBRACK statements RCBRACK ELSE LCBRACK statements RCBRACK
        | IF LPAREN logic_o RPAREN LCBRACK statements RCBRACK 
        | IF LPAREN comparison RPAREN LCBRACK statements RCBRACK ELSE LCBRACK statements RCBRACK
        | IF LPAREN comparison RPAREN LCBRACK statements RCBRACK 
    '''
    try:
        if p[3]:
            p[0] = p[6]
        elif not(p[3]):
            p[0] = p[10]
    except IndexError:
        if p[3]:
            p[0] = p[6]

def p_assign_s(p):
    '''
        assign_s : INTEGER_TYPE ID ASSIGN arithmetic_o
        | BOOL_TYPE ID ASSIGN logic_o 
        | STRING_TYPE ID ASSIGN string_o
    '''
    variables[p[2]] = p[4]

def p_comparison_o(p):
    '''
        comparison : arithmetic_o GTS arithmetic_o
        | arithmetic_o LTS arithmetic_o
        | arithmetic_o EQ arithmetic_o
        | string_o EQ string_o
    '''
    if p[2] == ">":
        p[0] = p[1] > p[3]
    elif p[2] == "<":
        p[0] = p[1] < p[3]
    elif p[2] == "==":
        if type(p[3]) == str or type(p[1]) == str: 
            p[0] = p[3].replace("\"", "") == p[1].replace("\"", "")
        else:
            p[0] = p[1] == p[3]

def p_string_o(p):
    '''
        string_o : string_o PLUS z
        | z
        z : variable
        | STRING
    '''
    if len(p.slice) > 2:
        if p[2] == '+':
            p[0] = p[1] + p[3]
    else:
        p[0] = p[1]

def p_logic_o(p):
    '''
        logic_o : logic_o AND m
        | m
        m : m OR n
        | n
        n : LPAREN logic_o RPAREN
        | comparison
        | NOT LPAREN logic_o RPAREN
        | variable
        | BOOL
    '''
    if len(p.slice) > 2:
        if p[2] == "or":
            p[0] = p[1] or p[3]
        elif p[2] == "and":
            p[0] = p[1] and p[3]
        elif p[1] == "not":
            p[0] = not(p[3])
        elif p[1] == "(" and p[3] == ")":
            p[0] = p[2]
    else:
        p[0] = p[1]

def p_arithmetic_o(p):
    '''
        arithmetic_o : arithmetic_o PLUS f
                 | arithmetic_o MINUS f
                 | f
        f : LPAREN arithmetic_o RPAREN
          | INTEGER 
          | variable
    '''
    if len(p.slice) > 2:
        if p[2] == '+':
            p[0] = p[1] + p[3]
        elif p[2] == '-':
            p[0] = p[1] - p[3]
        elif p[1] == '(' and p[3] == ')':
            p[0] = p[2]
    else:
        p[0] = p[1]

def p_variable(p):
    '''
        variable : ID
    '''
    try:
        p[0] = variables[p[1]]
    except:
        print("not found")
        p[0] = 0

def p_output(p):
    '''
        output : OUTPUT LPAREN ID RPAREN 
        | OUTPUT LPAREN STRING RPAREN 
        | OUTPUT LPAREN BOOL RPAREN 
        | OUTPUT LPAREN INTEGER RPAREN 
    '''
    if p[3] in variables.keys():
        if type(variables[p[3]]) == str:
            # print(variables[p[3]].replace("\"", ""))
            p[0] = variables[p[3]].replace("\"", "")
        else:
            # print(variables[p[3]])
            p[0] = variables[p[3]]
    elif type(p[3]) == int or type(p[3]) == bool:
        # print(p[3])
        p[0] = p[3]
    elif "\"" in p[3]:
        # print(p[3].replace("\"", ""))
        p[0] = p[3].replace("\"", "")
    else:
        print("undefined variable")

def p_input(p):
    '''
        input : INTEGER_TYPE ID ASSIGN INPUT LPAREN RPAREN
        | STRING_TYPE ID ASSIGN INPUT LPAREN RPAREN 
        | BOOL_TYPE ID ASSIGN INPUT LPAREN RPAREN 
    '''
    if p[1] == "string":
        variables[p[2]] = str(input())
    elif p[1] == "integer":
        variables[p[2]] = int(input())
    elif p[1] == "bool":
        variables[p[2]] = bool(input())

def p_type_cast(p):
    '''
        type_cast :  INTEGER_TYPE ID ASSIGN INT LPAREN INPUT LPAREN RPAREN RPAREN 
        | INTEGER_TYPE ID ASSIGN INT LPAREN ID RPAREN 
        | STRING_TYPE ID ASSIGN STR LPAREN INPUT LPAREN RPAREN RPAREN 
        | STRING_TYPE ID ASSIGN STR LPAREN ID RPAREN 
    '''
    if p[1] == "integer":
        if p[6] == "input":
            variables[p[2]] = int(input())
        else:
            variables[p[2]] = int(variables[p[6]].replace("\"",""))
    if p[1] == "string":
        if p[6] == "input":
            variables[p[2]] = str(input())
        else:
            variables[p[2]] = str(variables[p[6]])




example1 = """
class main{
	integer a = 10;
	while(10 == a){
		output(a);
    }
}
"""
example2 = '''
class main{
	integer num = INT(input());
	if(5 < num){
		output("input is : ");
		output(num);
	}
}
'''
example3 = '''
class main{
	string s = input();
	if(s == "YES"){
		output("yes");
	}
	else{
		output("no");
	}
} 
'''
example4 = '''
class main{
    string a_string = input();
    integer b_integer = INT(input());

    integer a_integer = INT(a_string);
    string b_string = STR(b_integer);

    integer c = a_integer + 2;
    string d = b_string + "2";

    output(c);
    output(d);
}
'''

parser = yacc.yacc(debug=False)
# print(parser.parse(example4))

while True:
    try:
        s = input("budgetPython > ")
    except:
        break
    if not s:
        continue
    lexer.input(s)
    for tok in lexer:
        print(tok)
    result = parser.parse(s)
    if result is not None:
        print(result)
        